import java.util.Set;
import java.util.List;
import java.util.*;

class Constant
{
    private String name;
    public Constant(String name) {this.name = name; }

    public String name(){ return this.name; }
    public String eval(Structure m) { return m.iC(name()); }

    @Override
    public String toString() { return this.name;}

    @Override
    public boolean equals(Object other) {
        if ( getClass() != other.getClass()){ return false;}
        Constant otherC = (Constant)other;
        return name() == otherC.name();
    }

}
public class Formula
{
}
